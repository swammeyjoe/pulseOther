package us.pulseapp.pulse;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.Marker;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.provider.SyncStateContract.Constants;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class MainActivity extends ActionBarActivity implements
		ConnectionCallbacks, OnConnectionFailedListener {

	private GoogleApiClient tGoogleApiClient;
	private LatLng myLocation;
	private Double lat;
	private Double lon;
	private GoogleMap map;
	private Marker marker;
	View  view = null, mapView = null;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buildGoogleApiClient();
        map = ((MapFragment) (getFragmentManager().findFragmentById(R.id.map))).getMap();


        
    }
    public void onActivityCreated() {
    	
    }
    
   
    protected synchronized void buildGoogleApiClient() {
        tGoogleApiClient = new GoogleApiClient.Builder(this)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .addApi(LocationServices.API)
            .build();
    }
    
    protected void onStart() {
        super.onStart();
        tGoogleApiClient.connect();
    }
    
   @Override
   public void onConnected(Bundle connectionHint) {
 	   Location lastLoc = LocationServices.FusedLocationApi.getLastLocation(
               tGoogleApiClient);
 	  if (lastLoc != null) {
 		  lat = lastLoc.getLatitude();
 		  lon = lastLoc.getLongitude();
 		  System.out.println(lat);
 		  System.out.println(lon);

 		  myLocation = new LatLng(lat, lon);
		  map.animateCamera(CameraUpdateFactory.newLatLngZoom(myLocation,
		            14));
		  drawCircleOnMap(myLocation);
      }
   }
   
   @Override
   public void onConnectionFailed(ConnectionResult result) {
	   
   }
   
   @Override
   public void onConnectionSuspended(int cause) {
	   
   }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    //The "Send Pulse" button was clicked.
    public void buttonClicked (View view) {
    	Intent intent = new Intent(this, FriendSelectionActivity.class);
        startActivityForResult(intent,0);    	
    }
    
    /* 
     * TODO (Zach & Jeremiah): Render circle
     * Two options for drawing the circle. #1 uses the google maps circles.
     * Option #2 uses an image that is pinned onto the map. I'm trying to
     * figure out how to get it stuck on the screen instead. Both methods
     * seem to suck. A third possibility that I think is best is to use a
     * frame layout and stick an image of a circle on top of the map. 
     */
    public void drawCircleOnMap(LatLng ll) {
	 	   
	 // #1	  
	// 	   CircleOptions circleOptions = new CircleOptions()
	// 	    .center(ll)
	// 	    .radius(1000); // In meters
	//      Circle circle = map.addCircle(circleOptions);
	  
	 // #2	   
	// 	   MarkerOptions markerOptions = new MarkerOptions().position(ll);
	// 	   markerOptions = markerOptions.icon(BitmapDescriptorFactory.fromAsset("circle.png"));
	// 	   marker = map.addMarker(markerOptions);
	    }
}
