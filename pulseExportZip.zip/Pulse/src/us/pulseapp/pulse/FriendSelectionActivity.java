package us.pulseapp.pulse;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class FriendSelectionActivity extends Activity {
	private ArrayAdapter adapter;
	private ArrayAdapter<String> adapter2;
	private String[] mockData = {"Test Name 1", "Test Name 2"};
	private ListView listView;
	@Override
	protected void onCreate(Bundle savedInstanceState){
		 super.onCreate(savedInstanceState);
	     setContentView(R.layout.activity_friend_selection);
		
		//use this to do custom UI on text boxes
		adapter = new ArrayAdapter(this, R.layout.list_item, mockData);
		
//		use this just for proof of concept
//		adapter2 = new ArrayAdapter<String>(this,
//		        android.R.layout.simple_list_item_1, mockData);
		
		listView = (ListView) findViewById(R.id.list_item_field);
		listView.setAdapter(adapter);
		
		listView.setOnItemClickListener(
		  new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				//handle click of item				
			}
		  });
	}
	
	@Override
	protected void onPause () {
		
	}
    //The "Send Pulse" button was clicked.
    public void sendPulse (View view) {
    	//this is where we dispatch notifications via Parse
    	Intent intent = new Intent(this, MyActivity.class);
        startActivityForResult(intent,0);   
    }
	
}