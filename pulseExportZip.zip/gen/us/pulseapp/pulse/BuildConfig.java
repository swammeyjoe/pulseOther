/** Automatically generated file. DO NOT MODIFY */
package us.pulseapp.pulse;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}