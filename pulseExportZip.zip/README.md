Pulse
=====

The app of the ages

App id: 1514044822175965



Dependencies
=====================

Currently using facebook android sdk version 3.19.1

    Here's a link to help set it up in android studio:
    http://stackoverflow.com/questions/24466921/android-studio-0-8-1-how-to-use-facebook-sdk


Currently using version 1.8.0
Parse info: 
    Username: freddysalinas801@gmail.com
    Password: Pulse4LyfeHolmes
